## Bill making app
* It is to make Bill for travel agent.
* HTML+CSS+JAVASCRIPT is used
